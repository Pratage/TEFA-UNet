import torch
import torch.nn as nn
import torch.nn.functional as F

class DMlp(nn.Module):
    """
    Depthwise Multi-Layer Perceptron for local texture extraction.
    """
    def __init__(self, dim, growth_rate=2.0):
        super().__init__()
        hidden_dim = int(dim * growth_rate)
        self.conv_0 = nn.Sequential(
            nn.Conv2d(dim, hidden_dim, 3, 1, 1, groups=dim),
            nn.Conv2d(hidden_dim, hidden_dim, 1, 1, 0)
        )
        self.act = nn.GELU()
        self.conv_1 = nn.Conv2d(hidden_dim, dim, 1, 1, 0)

    def forward(self, x):
        x = self.conv_0(x)
        x = self.act(x)
        x = self.conv_1(x)
        return x

class PCFN(nn.Module):
    def __init__(self, dim, growth_rate=2.0, p_rate=0.25):
        super().__init__()
        hidden_dim = int(dim * growth_rate)
        p_dim = int(hidden_dim * p_rate)
        self.conv_0 = nn.Conv2d(dim, hidden_dim, 1, 1, 0)
        self.conv_1 = nn.Conv2d(p_dim, p_dim, 3, 1, 1)

        self.act = nn.GELU()
        self.conv_2 = nn.Conv2d(hidden_dim, dim, 1, 1, 0)

        self.p_dim = p_dim
        self.hidden_dim = hidden_dim

    def forward(self, x):
        if self.training:
            x = self.act(self.conv_0(x))
            x1, x2 = torch.split(x, [self.p_dim, self.hidden_dim - self.p_dim], dim=1)
            x1 = self.act(self.conv_1(x1))
            x = self.conv_2(torch.cat([x1, x2], dim=1))
        else:
            x = self.act(self.conv_0(x))
            x[:, :self.p_dim, :, :] = self.act(self.conv_1(x[:, :self.p_dim, :, :]))
            x = self.conv_2(x)
        return x

class LGA(nn.Module):
    """
    Local-Global Aggregation (LGA) core module.
    Balances fine-grained local textures and long-range global dependencies.
    """
    def __init__(self, dim=36):
        super(LGA, self).__init__()
        self.linear_0 = nn.Conv2d(dim, dim * 2, 1, 1, 0)
        self.linear_1 = nn.Conv2d(dim, dim, 1, 1, 0)
        self.linear_2 = nn.Conv2d(dim, dim, 1, 1, 0)

        # Local Texture Distiller (LTD)
        self.lde = DMlp(dim, 2)

        # Global Context Modulator (GCM)
        self.dw_conv = nn.Conv2d(dim, dim, 3, 1, 1, groups=dim)
        self.gelu = nn.GELU()
        self.down_scale = 8

        # Learnable modulation parameters
        self.alpha = nn.Parameter(torch.ones((1, dim, 1, 1)))
        self.belt = nn.Parameter(torch.zeros((1, dim, 1, 1)))
        self.gamma = nn.Parameter(torch.ones(1) * 1e-6)

    def forward(self, f):
        identity = f
        _, _, h, w = f.shape
        
        # Chunk into parallel components Y and X
        y, x = self.linear_0(f).chunk(2, dim=1)
        
        # Global Context Modulator branch
        x_s = self.dw_conv(F.adaptive_max_pool2d(x, (h // self.down_scale, w // self.down_scale)))
        x_v = torch.var(x, dim=(-2, -1), keepdim=True)
        x_l = x * F.interpolate(self.gelu(self.linear_1(x_s * self.alpha + x_v * self.belt)), size=(h, w), mode='nearest')
        
        # Local Texture Distiller branch
        y_d = self.lde(y)
        
        # Aggregation
        res = self.linear_2(x_l + y_d)
    
        # Gamma-weighted residual integration
        return identity + self.gamma * res

class LGABlock(nn.Module):
    """
    Plug-and-play LGA Node designed specifically for the TEFA-UNet architecture.
    """
    def __init__(self, in_ch, out_ch):
        super(LGABlock, self).__init__()
        # 1. 1x1 Conv to compress channels, solving the dimension doubling issue after concatenation
        self.compress = nn.Conv2d(in_ch, out_ch, kernel_size=1)
        
        # 2. The core LGA feature aggregation
        self.lga = LGA(dim=out_ch)
        
        # 3. Batch Normalization and ReLU for stable training
        self.bn = nn.BatchNorm2d(out_ch)
        self.relu = nn.ReLU(inplace=True)

    def forward(self, x):
        x = self.compress(x)         # Align channel dimensions
        x = self.lga(x)              # Core Local-Global feature aggregation
        return self.relu(self.bn(x)) # Residual activation

if __name__ == '__main__':
    # Test the LGABlock
    model = LGABlock(in_ch=64, out_ch=32)
    output = model(torch.rand(1, 64, 256, 256))
    print('LGABlock output_size:', output.size())