import torch
import torch.nn as nn
from torchvision.ops import StochasticDepth as DropPath

class h_sigmoid(nn.Module):
    """
    Hard Sigmoid activation function.
    """
    def __init__(self, inplace=True):
        super(h_sigmoid, self).__init__()
        self.relu = nn.ReLU6(inplace=True)

    def forward(self, x):
        return self.relu(x + 3) / 6

class Conv2d_BN(nn.Module):
    """
    Standard Convolution + Batch Normalization + Activation.
    """
    def __init__(self, in_features, out_features=None, kernel_size=3, stride=1, padding=0, act_layer=nn.ReLU, dilation=1, groups=1, bn_weight_init=1):
        super().__init__()
        self.conv = nn.Conv2d(in_features, out_features, kernel_size, stride, padding, dilation, groups, bias=False)
        self.bn = nn.BatchNorm2d(out_features)
        torch.nn.init.constant_(self.bn.weight, bn_weight_init)
        torch.nn.init.constant_(self.bn.bias, 0)
        self.act = act_layer(inplace=True)

    def forward(self, x):
        x = self.conv(x)
        x = self.bn(x)
        x = self.act(x)
        return x

class MSRBlock(nn.Module):
    """
    Multi-Scale Refinement (MSR) Block.
    1. Multi-scale capture: Extracts features using multiple parallel branches with different receptive fields.
    2. Fusion strategy: Concatenates and compresses multi-scale features to enrich boundary semantics.
    """
    def __init__(self, dim, scales=(1, 3, 5), reduction_ratio=4):
        super(MSRBlock, self).__init__()
        self.dim = dim
        self.scales = scales

        # Multi-scale parallel convolutional branches
        self.scale_convs = nn.ModuleList([
            Conv2d_BN(dim, dim // reduction_ratio, kernel_size=scale, padding=scale // 2)
            for scale in scales
        ])
        
        # 1x1 Convolution to fuse the concatenated multi-scale branches back to the original dimension
        self.fuse_conv = Conv2d_BN(dim // reduction_ratio * len(scales), dim, kernel_size=1)

    def forward(self, x):
        # Extract features across different scale branches
        scale_features = [conv(x) for conv in self.scale_convs]
        
        # Concatenate multi-scale features along the channel dimension
        fused_features = torch.cat(scale_features, dim=1)  
        
        # Fuse and output
        return self.fuse_conv(fused_features)

if __name__ == "__main__":
    # Test the MSRBlock
    MSR_module = MSRBlock(dim=64, scales=(1, 3, 5))
    input_tensor = torch.randn(2, 64, 32, 32)
    output_tensor = MSR_module(input_tensor)
    print(f"Input shape: {input_tensor.shape}")
    print(f"Output shape: {output_tensor.shape}")