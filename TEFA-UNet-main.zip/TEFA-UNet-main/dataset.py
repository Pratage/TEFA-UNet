import numpy as np
import cv2 
import random

from skimage.io import imread
from skimage import color

import torch
import torch.utils.data
from torchvision import datasets, models, transforms


class Dataset(torch.utils.data.Dataset):

    def __init__(self, args, img_paths, mask_paths, aug=False):
        self.args = args
        self.img_paths = img_paths
        self.mask_paths = mask_paths
        self.aug = aug

    def __len__(self):
        return len(self.img_paths)

    def __getitem__(self, idx):
        img_path = self.img_paths[idx]
        mask_path = self.mask_paths[idx]
        npimage = np.load(img_path)
        npmask = np.load(mask_path)
        
        # 1. Label decoupling (WT, TC, ET)
        WT_Label = npmask.copy()
        WT_Label[npmask == 1] = 1.
        WT_Label[npmask == 2] = 1.
        WT_Label[npmask == 4] = 1.
        
        TC_Label = npmask.copy()
        TC_Label[npmask == 1] = 1.
        TC_Label[npmask == 2] = 0.
        TC_Label[npmask == 4] = 1.
        
        ET_Label = npmask.copy()
        ET_Label[npmask == 1] = 0.
        ET_Label[npmask == 2] = 0.
        ET_Label[npmask == 4] = 1.

        # 2. Label processing (Maintain H, W, 3 order)
        nplabel = np.empty((160, 160, 3))
        nplabel[:, :, 0] = WT_Label
        nplabel[:, :, 1] = TC_Label
        nplabel[:, :, 2] = ET_Label

        # 3. Data augmentation: Performed in H, W, C format
        if self.aug:
            if random.random() > 0.5:
                # Horizontal flip: Operating on the first two spatial axes
                npimage = npimage[:, ::-1, :]
                nplabel = nplabel[:, ::-1, :]
            if random.random() > 0.5:
                # Vertical flip
                npimage = npimage[::-1, :, :]
                nplabel = nplabel[::-1, :, :]
            if random.random() > 0.5:
                # Rotation: Operating on the (0, 1) spatial axes
                k = random.randint(1, 3)
                npimage = np.rot90(npimage, k, axes=(0, 1))
                nplabel = np.rot90(nplabel, k, axes=(0, 1))

        # 4. [Critical Fix] Unified dimension transposition
        # Whether augmentation is performed or not, finally transpose to (C, H, W)
        npimage = npimage.transpose((2, 0, 1))
        nplabel = nplabel.transpose((2, 0, 1))

        # 5. Must use .copy() to fix memory discontinuity caused by flipping
        # Meanwhile, ensure the data type is float32
        npimage = npimage.copy().astype("float32")
        nplabel = nplabel.copy().astype("float32")

        return npimage, nplabel
        
        '''
        # Code for reading standard images (e.g., jpg, png)
        image = imread(img_path)
        mask = imread(mask_path)

        image = image.astype('float32') / 255
        mask = mask.astype('float32') / 255

        if self.aug:
            if random.uniform(0, 1) > 0.5:
                image = image[:, ::-1, :].copy()
                mask = mask[:, ::-1].copy()
            if random.uniform(0, 1) > 0.5:
                image = image[::-1, :, :].copy()
                mask = mask[::-1, :].copy()

        image = color.gray2rgb(image)
        #image = image[:,:,np.newaxis]
        image = image.transpose((2, 0, 1))
        mask = mask[:,:,np.newaxis]
        mask = mask.transpose((2, 0, 1))       
        return image, mask
        '''