# -*- coding: utf-8 -*-
import torch
import torch.nn as nn
from LGA_block import LGABlock
from MSR_block import MSRBlock

class VGGBlock(nn.Module):
    """
    Standard VGG Block for local feature extraction.
    Consists of two consecutive 3x3 convolutions with BN and ReLU.
    """
    def __init__(self, in_channels, middle_channels, out_channels, act_func=nn.ReLU(inplace=True)):
        super(VGGBlock, self).__init__()
        self.act_func = act_func
        self.conv1 = nn.Conv2d(in_channels, middle_channels, 3, padding=1)
        self.bn1 = nn.BatchNorm2d(middle_channels)
        self.conv2 = nn.Conv2d(middle_channels, out_channels, 3, padding=1)
        self.bn2 = nn.BatchNorm2d(out_channels)

    def forward(self, x):
        out = self.conv1(x)
        out = self.bn1(out)
        out = self.act_func(out)

        out = self.conv2(out)
        out = self.bn2(out)
        out = self.act_func(out)

        return out

class TEFAUNet(nn.Module):
    """
    TEFA-UNet: Texture-aware and Efficient Fusion-Attention U-shaped Network.
    Integrates LGA blocks in the encoder and MSR blocks at the decoder output.
    """
    def __init__(self, args):
        super().__init__()
        self.args = args
        num_class = 3
        num_channels = 4  # e.g., T1, T2, T1ce, FLAIR
        nb_filter = [32, 64, 128, 256, 512]

        # --------------------------------------------------------------------------
        # Encoder (with LGA Blocks)
        # --------------------------------------------------------------------------
        self.conv0_0 = VGGBlock(num_channels, nb_filter[0], nb_filter[0])
        self.lga0_0 = LGABlock(nb_filter[0], nb_filter[0])
        
        self.conv1_0 = VGGBlock(nb_filter[0], nb_filter[1], nb_filter[1])
        self.lga1_0 = LGABlock(nb_filter[1], nb_filter[1])
        
        self.conv2_0 = VGGBlock(nb_filter[1], nb_filter[2], nb_filter[2])
        self.lga2_0 = LGABlock(nb_filter[2], nb_filter[2])
        
        self.conv3_0 = VGGBlock(nb_filter[2], nb_filter[3], nb_filter[3])
        self.lga3_0 = LGABlock(nb_filter[3], nb_filter[3])
        
        self.conv4_0 = VGGBlock(nb_filter[3], nb_filter[4], nb_filter[4])
        self.lga4_0 = LGABlock(nb_filter[4], nb_filter[4])

        self.pool = nn.MaxPool2d(2, 2)
        self.up = nn.Upsample(scale_factor=2, mode='bilinear', align_corners=True)

        # --------------------------------------------------------------------------
        # Nested Fusion Pathways
        # --------------------------------------------------------------------------
        self.conv0_1 = VGGBlock(nb_filter[0]+nb_filter[1], nb_filter[0], nb_filter[0])
        self.conv1_1 = VGGBlock(nb_filter[1]+nb_filter[2], nb_filter[1], nb_filter[1])
        self.conv2_1 = VGGBlock(nb_filter[2]+nb_filter[3], nb_filter[2], nb_filter[2])
        self.conv3_1 = VGGBlock(nb_filter[3]+nb_filter[4], nb_filter[3], nb_filter[3])

        self.conv0_2 = VGGBlock(nb_filter[0]*2+nb_filter[1], nb_filter[0], nb_filter[0])
        self.conv1_2 = VGGBlock(nb_filter[1]*2+nb_filter[2], nb_filter[1], nb_filter[1])
        self.conv2_2 = VGGBlock(nb_filter[2]*2+nb_filter[3], nb_filter[2], nb_filter[2])

        # --------------------------------------------------------------------------
        # Decoder outputs (with MSR Blocks)
        # --------------------------------------------------------------------------
        self.msr0_3 = MSRBlock(dim=nb_filter[0], scales=(1, 3, 5), reduction_ratio=4)
        self.conv0_3 = VGGBlock(nb_filter[0]*3+nb_filter[1], nb_filter[0], nb_filter[0])
        self.conv1_3 = VGGBlock(nb_filter[1]*3+nb_filter[2], nb_filter[1], nb_filter[1])

        self.msr0_4 = MSRBlock(dim=nb_filter[0], scales=(1, 3, 5), reduction_ratio=4)
        self.conv0_4 = VGGBlock(nb_filter[0]*4+nb_filter[1], nb_filter[0], nb_filter[0])

        # Dense Classifier Output
        if self.args.deepsupervision:
            self.final1 = nn.Conv2d(nb_filter[0], num_class, kernel_size=1)
            self.final2 = nn.Conv2d(nb_filter[0], num_class, kernel_size=1)
            self.final3 = nn.Conv2d(nb_filter[0], num_class, kernel_size=1)
            self.final4 = nn.Conv2d(nb_filter[0], num_class, kernel_size=1)
        else:
            self.final = nn.Conv2d(nb_filter[0], num_class, kernel_size=1)


    def forward(self, x):
        # ------------------- Encoder -------------------
        x0_0 = self.conv0_0(x)
        x0_0 = self.lga0_0(x0_0) 

        x1_0 = self.conv1_0(self.pool(x0_0))
        x1_0 = self.lga1_0(x1_0)

        x2_0 = self.conv2_0(self.pool(x1_0))
        x2_0 = self.lga2_0(x2_0) 

        x3_0 = self.conv3_0(self.pool(x2_0))
        x3_0 = self.lga3_0(x3_0)

        x4_0 = self.conv4_0(self.pool(x3_0))
        x4_0 = self.lga4_0(x4_0)

        # ------------------- Nested Fusion -------------------
        x0_1 = self.conv0_1(torch.cat([x0_0, self.up(x1_0)], 1))
        
        x1_1 = self.conv1_1(torch.cat([x1_0, self.up(x2_0)], 1))
        x0_2 = self.conv0_2(torch.cat([x0_0, x0_1, self.up(x1_1)], 1))

        x2_1 = self.conv2_1(torch.cat([x2_0, self.up(x3_0)], 1))
        x1_2 = self.conv1_2(torch.cat([x1_0, x1_1, self.up(x2_1)], 1))
        
        x0_3 = self.conv0_3(torch.cat([x0_0, x0_1, x0_2, self.up(x1_2)], 1))
        x0_3 = self.msr0_3(x0_3) # Refinement node

        x3_1 = self.conv3_1(torch.cat([x3_0, self.up(x4_0)], 1))
        x2_2 = self.conv2_2(torch.cat([x2_0, x2_1, self.up(x3_1)], 1))
        x1_3 = self.conv1_3(torch.cat([x1_0, x1_1, x1_2, self.up(x2_2)], 1))
        
        x0_4 = self.conv0_4(torch.cat([x0_0, x0_1, x0_2, x0_3, self.up(x1_3)], 1))
        x0_4 = self.msr0_4(x0_4) # Final Refinement node

        # ------------------- Output Mapping -------------------
        if self.args.deepsupervision:
            output1 = self.final1(x0_1)
            output2 = self.final2(x0_2)
            output3 = self.final3(x0_3)
            output4 = self.final4(x0_4)
            return [output1, output2, output3, output4]
        else:
            output = self.final(x0_4)
            return output