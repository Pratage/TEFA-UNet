# -*- coding: utf-8 -*-

import time
import os
import math
import argparse
from glob import glob
from collections import OrderedDict
import random
import warnings
from datetime import datetime

import numpy as np
from tqdm import tqdm

from sklearn.model_selection import train_test_split
from skimage.io import imread, imsave

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.autograd import Variable
import torch.optim as optim
from torch.optim import lr_scheduler
from torch.utils.data import DataLoader
import torch.backends.cudnn as cudnn
import torchvision
from torchvision import datasets, models, transforms

from dataset import Dataset

# 1. Changed module name to match the paper's architecture
import tefa_unet 
from metrics import dice_coef, batch_iou, mean_iou, iou_score, ppv, sensitivity
import losses
from utils import str2bool, count_params
import joblib

# HD95 Metric integration for boundary evaluation
from medpy.metric.binary import hd95
import imageio

# Data paths for testing
IMG_PATH = glob(r"..\..\data\processed\2D\testImage\*")
MASK_PATH = glob(r"..\..\data\processed\2D\testMask\*")

# Execution modes: run 'GetPicture' first, followed by 'Calculate'
MODE = 'Calculate'

def parse_args():
    parser = argparse.ArgumentParser()
    # 2. Changed default model name to match TEFAUNet
    parser.add_argument('--name', default='jiu0Monkey_TEFAUNet_woDS', help='model name')
    parser.add_argument('--mode', default=MODE, help='GetPicture or Calculate')
    args = parser.parse_args()
    return args

def main():
    val_args = parse_args()
    args = joblib.load('models/%s/args.pkl' % val_args.name)

    if not os.path.exists('output3/%s' % args.name):
        os.makedirs('output3/%s' % args.name)

    print('Config -----')
    for arg in vars(args):
        print('%s: %s' % (arg, getattr(args, arg)))
    print('------------')

    joblib.dump(args, 'models/%s/args.pkl' % args.name)

    # Create model
    print("=> creating model %s" % args.arch)
    # 3. Instantiate the TEFA-UNet model from the updated module
    model = tefa_unet.__dict__[args.arch](args)
    model = model.cuda()

    model.load_state_dict(torch.load('models/%s/model.pth' % args.name))
    model.eval()

    val_dataset = Dataset(args, IMG_PATH, MASK_PATH)
    val_loader = torch.utils.data.DataLoader(
        val_dataset,
        batch_size=args.batch_size,
        shuffle=False,
        pin_memory=True,
        drop_last=False)

    # ========================== Mode 1: GetPicture ==========================
    if val_args.mode == "GetPicture":
        print("Starting GetPicture Mode...")
        with warnings.catch_warnings():
            warnings.simplefilter('ignore')
            with torch.no_grad():
                for i, (input, target) in tqdm(enumerate(val_loader), total=len(val_loader)):
                    input = input.cuda()
                    if args.deepsupervision:
                        output = model(input)[-1]
                    else:
                        output = model(input)

                    output = torch.sigmoid(output).data.cpu().numpy()
                    current_img_paths = IMG_PATH[args.batch_size * i : args.batch_size * (i + 1)]

                    for b in range(output.shape[0]):
                        npName = os.path.basename(current_img_paths[b])
                        rgbName = npName.replace(".npy", ".png")
                        rgbPic = np.zeros([160, 160, 3], dtype=np.uint8)
                        for idx in range(output.shape[2]):
                            for idy in range(output.shape[3]):
                                # NCR (Label 1) -> Green [0, 128, 0]
                                if output[b, 0, idx, idy] > 0.5:
                                    rgbPic[idx, idy, 1] = 128
                                # ED (Label 2) -> Red [255, 0, 0]
                                if output[b, 1, idx, idy] > 0.5:
                                    rgbPic[idx, idy, 0] = 255
                                # ET (Label 4) -> Yellow [255, 255, 0]
                                if output[b, 2, idx, idy] > 0.5:
                                    rgbPic[idx, idy, 0] = 255
                                    rgbPic[idx, idy, 1] = 255
                        imsave('output3/%s/%s' % (args.name, rgbName), rgbPic)

        # Save Ground Truth annotations as images
        print("Saving GT to picture...")
        val_gt_path = 'output3/%s/GT/' % args.name
        if not os.path.exists(val_gt_path): os.makedirs(val_gt_path)
        for mask_p in tqdm(MASK_PATH):
            name = os.path.basename(mask_p).replace(".npy", ".png")
            npmask = np.load(mask_p)
            GtColor = np.zeros([npmask.shape[0], npmask.shape[1], 3], dtype=np.uint8)
            for idx in range(npmask.shape[0]):
                for idy in range(npmask.shape[1]):
                    if npmask[idx, idy] == 1: GtColor[idx, idy, 0] = 255 # Red
                    elif npmask[idx, idy] == 2: GtColor[idx, idy, 1] = 128 # Green
                    elif npmask[idx, idy] == 4: # Yellow
                        GtColor[idx, idy, 0] = 255
                        GtColor[idx, idy, 1] = 255
            imageio.imwrite(val_gt_path + name, GtColor)
        print("GetPicture Done!")

    # ========================== Mode 2: Calculate ==========================
    if val_args.mode == "Calculate":
        print("Starting Calculate Mode...")
        wt_dices, tc_dices, et_dices = [], [], []
        wt_sensitivities, tc_sensitivities, et_sensitivities = [], [], []
        wt_ppvs, tc_ppvs, et_ppvs = [], [], []
        wt_HD95, tc_HD95, et_HD95 = [], [], []

        # Sort files to correctly align predictions with ground truths
        maskPath = sorted(glob("output3/%s/GT/*.png" % args.name))
        pbPath = sorted(glob("output3/%s/*.png" % args.name))

        if len(maskPath) == 0:
            print("Please run 'GetPicture' mode first to generate images!")
            return

        for myi in tqdm(range(len(maskPath))):
            mask = imread(maskPath[myi])
            pb = imread(pbPath[myi])

            # Use matrix operations to accelerate calculation and fix ET logic
            # WT (Whole Tumor): Any channel has values
            wtmaskregion = np.any(mask > 0, axis=-1).astype(np.float32)
            wtpbregion   = np.any(pb > 0, axis=-1).astype(np.float32)

            # TC (Tumor Core): Red channel is 255 (NCR and ET)
            tcmaskregion = (mask[:, :, 0] == 255).astype(np.float32)
            tcpbregion   = (pb[:, :, 0] == 255).astype(np.float32)

            # ET (Enhancing Tumor): Yellow is [255, 255, 0], so evaluate R=255 and G=255
            etmaskregion = ((mask[:, :, 0] == 255) & (mask[:, :, 1] == 255)).astype(np.float32)
            etpbregion   = ((pb[:, :, 0] == 255) & (pb[:, :, 1] == 255)).astype(np.float32)

            # Generalized function for calculating evaluation metrics
            def get_metrics(pred, gt, d_list, p_list, s_list, h_list):
                d_list.append(dice_coef(pred, gt))
                p_list.append(ppv(pred, gt))
                s_list.append(sensitivity(pred, gt))
                # Calculate HD95 and prevent empty mask errors
                if np.sum(pred) > 0 and np.sum(gt) > 0:
                    h_list.append(hd95(pred, gt))
                else:
                    h_list.append(0.0)

            get_metrics(wtpbregion, wtmaskregion, wt_dices, wt_ppvs, wt_sensitivities, wt_HD95)
            get_metrics(tcpbregion, tcmaskregion, tc_dices, tc_ppvs, tc_sensitivities, tc_HD95)
            get_metrics(etpbregion, etmaskregion, et_dices, et_ppvs, et_sensitivities, et_HD95)

        # Print output metrics matching the paper's table formatting
        print('\n' + "="*45)
        print('WT Dice: %.4f | TC Dice: %.4f | ET Dice: %.4f' % (np.mean(wt_dices), np.mean(tc_dices), np.mean(et_dices)))
        print('WT HD95: %.4f | TC HD95: %.4f | ET HD95: %.4f' % (np.mean(wt_HD95), np.mean(tc_HD95), np.mean(et_HD95)))
        print("="*45)

if __name__ == '__main__':
    main()